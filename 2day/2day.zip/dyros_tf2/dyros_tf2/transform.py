import math

def quaternion_from_euler(roll, pitch, yaw):

    cr = math.cos(roll*0.5)
    sr = math.sin(roll*0.5)

    cp = math.cos(pitch*0.5)
    sp = math.sin(pitch*0.5)

    cy = math.cos(yaw*0.5)
    sy = math.sin(yaw*0.5)

    q = [0, 0, 0, 0] 
        
    q[0] = sr*cp*cy - cr*sp*sy #q.x
    q[1] = cr*sp*cy + sr*cp*sy #q.y
    q[2] = cr*cp*sy - sr*sp*cy #q.z
    q[3] = cr*cp*cy + sr*sp*sy #q.w

    return q
